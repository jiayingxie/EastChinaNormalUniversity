import org.apache.commons.text.StringEscapeUtils;

/**
 * ����Apache Commons Text ����ַ�ת��
 * @author Tom
 *
 */
public class EscapeString {

	public static void main(String[] args) {
		String str = "He didn't say, \"Stop!\"";
        
		//ת��
		String escapedStr = StringEscapeUtils.escapeJava(str);
        System.out.println("escape" + ":" + escapedStr);
        
        //��ת���ַ���ת����
        String str2 = StringEscapeUtils.unescapeJava(escapedStr);
        System.out.println("unescape" + ":" + str2);
    }	
}
