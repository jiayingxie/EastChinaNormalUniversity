package genericclass;

public class Util {

	
}
