package genericinterface;

public interface Calculator<T> {
	public T add(T operand1, T operand2);
}


