
public interface Adder {

	public int selfAdd(int x);
	
}

