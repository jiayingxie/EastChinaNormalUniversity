package sugar.staticmethod;

public interface StaticAnimal {

	public static void move()
	{
		System.out.println("I can move");
	}
}

