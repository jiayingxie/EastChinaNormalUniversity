package sugar.defaultmethod;

public abstract class NewFlyAnimal implements NewAnimal{
	public void move()
	{
		System.out.println("I can move in sky");
	}
}
