package sugar.defaultmethod;

public class NewLion implements NewLandAnimal{

	public static void main(String[] args) {
		new NewLion().move();

	}

}
