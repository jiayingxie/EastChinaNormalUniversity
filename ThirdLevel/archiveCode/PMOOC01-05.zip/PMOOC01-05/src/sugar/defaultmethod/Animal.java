package sugar.defaultmethod;

public interface Animal {
	public void move();
}
