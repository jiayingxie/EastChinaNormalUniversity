package sugar.vars;

public class Father {

}
