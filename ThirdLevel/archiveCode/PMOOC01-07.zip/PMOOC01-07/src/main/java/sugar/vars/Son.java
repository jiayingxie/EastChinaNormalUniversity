package sugar.vars;

public class Son extends Father{

}
