
public class A {
	public void hello()
	{
		System.out.println("hello from A");
	}
}
