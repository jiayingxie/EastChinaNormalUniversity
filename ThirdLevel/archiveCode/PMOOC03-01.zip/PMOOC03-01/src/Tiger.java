
public class Tiger {

	public void move()
	{
		System.out.println("I can move fast");
	}
	public static void main(String[] args) {
		Tiger t = new Tiger();
		t.move();

	}

}
